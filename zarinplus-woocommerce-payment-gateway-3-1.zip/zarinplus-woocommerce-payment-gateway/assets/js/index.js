/**
 * ثبت درگاه‌های زرین‌پلاس در بلوک‌های ووکامرس
 */
(function () {
    var registerPaymentMethod = window.wc.wcBlocksRegistry.registerPaymentMethod;
    var getSetting = window.wc.wcSettings.getSetting;
    var decodeEntities = window.wp.htmlEntities.decodeEntities;

    function registerZarinplusGateway(gatewayId) {
        var settings = getSetting(gatewayId + '_data', {});

        if (!settings || !settings.title) {
            return;
        }

        var label = decodeEntities(settings.title) || '';

        var Icon = function () {
            return settings.icon
                ? React.createElement('img', {
                    src: settings.icon,
                    alt: label,
                    style: { marginLeft: '20px', maxHeight: '24px' }
                })
                : null;
        };

        var Label = function () {
            return React.createElement(
                'span',
                { style: { width: '100%', display: 'flex', gap: '5px', alignItems: 'center' } },
                label,
                React.createElement(Icon)
            );
        };

        var Content = function () {
            return decodeEntities(settings.description || '');
        };

        registerPaymentMethod({
            name: gatewayId,
            label: React.createElement(Label),
            content: React.createElement(Content),
            edit: React.createElement(Content),
            canMakePayment: function () { return true; },
            ariaLabel: label,
            supports: {
                features: settings.supports,
            },
        });
    }

    // ثبت همه درگاه‌ها از لیستی که PHP فرستاده
    if (typeof zarinplus_block_gateways !== 'undefined' && Array.isArray(zarinplus_block_gateways)) {
        zarinplus_block_gateways.forEach(function (gwId) {
            registerZarinplusGateway(gwId);
        });
    } else {
        // fallback: فقط درگاه اصلی
        registerZarinplusGateway('WC_ZarinPlus');
    }
})();
