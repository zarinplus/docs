<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * دریافت لیست درگاه‌های فعال از API زرین‌پلاس
 * fallback به دیتابیس اگه API جواب نده
 */
function zarinplus_get_gateways() {
    // کش runtime - در هر request فقط یکبار API زده بشه
    static $runtime_cache = null;
    if ($runtime_cache !== null) {
        return $runtime_cache;
    }

    // کش transient ۳ ساعته
    $cached = get_transient('zarinplus_gateways_list');
    if ($cached !== false) {
        $runtime_cache = $cached;
        return $cached;
    }

    $main_settings = get_option('woocommerce_WC_ZarinPlus_settings', array());
    $token = isset($main_settings['merchanttoken']) ? $main_settings['merchanttoken'] : '';

    if (empty($token)) {
        $runtime_cache = zarinplus_get_gateways_fallback();
        return $runtime_cache;
    }

    $response = wp_remote_post('https://api.zarinplus.com/payment/gateways/', array(
        'body' => json_encode(array('token' => $token)),
        'headers' => array('Content-Type' => 'application/json'),
        'method' => 'POST',
        'timeout' => 30,
    ));

    if (is_wp_error($response)) {
        $runtime_cache = zarinplus_get_gateways_fallback();
        return $runtime_cache;
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);

    if (!is_array($body) || !isset($body['status']) || $body['status'] !== true || empty($body['data'])) {
        $runtime_cache = zarinplus_get_gateways_fallback();
        return $runtime_cache;
    }

    $gateways = $body['data'];

    // fallback فقط زمانی آپدیت می‌شه که response معتبر و حداقل شامل درگاه اصلی زرین‌پلاس باشه
    // این از خراب شدن fallback با response ناقص API جلوگیری می‌کنه
    $has_main_zp = false;
    foreach ($gateways as $gw) {
        if (isset($gw['slug']) && $gw['slug'] === 'zarinplus') {
            $has_main_zp = true;
            break;
        }
    }

    if ($has_main_zp) {
        update_option('zarinplus_gateways_fallback', $gateways, false);
        // کش ۳ ساعته - فقط برای response معتبر
        set_transient('zarinplus_gateways_list', $gateways, 3 * HOUR_IN_SECONDS);
        $runtime_cache = $gateways;
        return $gateways;
    }

    // response مشکوک - از fallback استفاده می‌کنیم تا اطلاعات قبلی از بین نره
    $runtime_cache = zarinplus_get_gateways_fallback();
    return $runtime_cache;
}

function zarinplus_get_gateways_fallback() {
    $fallback = get_option('zarinplus_gateways_fallback', array());
    return is_array($fallback) ? $fallback : array();
}

function zarinplus_clear_gateways_cache() {
    delete_transient('zarinplus_gateways_list');
}

/**
 * گرفتن اطلاعات یک درگاه خاص از لیست کش‌شده
 */
function zarinplus_get_gateway_info($slug) {
    $gateways = zarinplus_get_gateways();
    if (is_array($gateways)) {
        foreach ($gateways as $gw) {
            if (isset($gw['slug']) && $gw['slug'] === $slug) {
                return $gw;
            }
        }
    }
    return null;
}

function Load_ZarinPlus_Gateway() {
    if (!class_exists('WC_Payment_Gateway') || class_exists('WC_ZarinPlus')) {
        return;
    }

    add_filter('woocommerce_currencies', 'add_IR_currency_zarinplus');
    function add_IR_currency_zarinplus($currencies) {
        $currencies['IRR'] = __('ریال', 'woocommerce');
        $currencies['IRT'] = __('تومان', 'woocommerce');
        $currencies['IRHR'] = __('هزار ریال', 'woocommerce');
        $currencies['IRHT'] = __('هزار تومان', 'woocommerce');
        return $currencies;
    }

    add_filter('woocommerce_currency_symbol', 'add_IR_currency_symbol_zarinplus', 10, 2);
    function add_IR_currency_symbol_zarinplus($currency_symbol, $currency) {
        switch ($currency) {
            case 'IRR':
                $currency_symbol = 'ریال';
                break;
            case 'IRT':
                $currency_symbol = 'تومان';
                break;
            case 'IRHR':
                $currency_symbol = 'هزار ریال';
                break;
            case 'IRHT':
                $currency_symbol = 'هزار تومان';
                break;
        }
        return $currency_symbol;
    }

    /**
     * کلاس پایه درگاه زرین پلاس
     */
    class WC_ZarinPlus extends WC_Payment_Gateway {
        protected $merchantToken;
        protected $failedMessage;
        protected $successMessage;
        protected $gateway_slug = 'zarinplus';

        public function __construct() {
            $this->id = 'WC_ZarinPlus';
            $this->gateway_slug = 'zarinplus';
            $this->method_title = __('پرداخت زرین پلاس', 'woocommerce');
            $this->method_description = __('پرداخت اعتباری زرین پلاس', 'woocommerce');
            $this->icon = apply_filters('WC_ZarinPlus_logo', plugin_dir_url(__FILE__) . 'assets/images/logo.png');

            $this->has_fields = false;
            $this->init_form_fields();
            $this->init_settings();

            $this->enabled = $this->get_option('enabled', 'yes');
            $this->title = $this->get_option('title', $this->method_title);
            $this->description = $this->get_option('description', $this->method_description);

            $this->merchantToken = $this->get_option('merchanttoken', '');
            $this->successMessage = $this->get_option('success_message', __('پرداخت شما با موفقیت انجام شد.', 'woocommerce'));
            $this->failedMessage = $this->get_option('failed_message', __('پرداخت شما با مشکل مواجه شد.', 'woocommerce'));

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, 'zarinplus_clear_gateways_cache');
            add_action('woocommerce_receipt_' . $this->id, array($this, 'send_to_zarinplus_gateway'));
            add_action('woocommerce_api_' . strtolower($this->id), array($this, 'return_from_zarinplus_gateway'));
        }

        public function init_form_fields() {
            $fields = array(
                'enabled' => array(
                    'title' => __('فعال‌سازی/غیرفعالسازی', 'woocommerce'),
                    'type' => 'checkbox',
                    'label' => __('فعال‌سازی افزونه پرداخت زرین پلاس', 'woocommerce'),
                    'description' => __('با غیرفعال کردن این گزینه، تمامی درگاه‌های زرین پلاس غیرفعال می‌شوند.', 'woocommerce'),
                    'default' => 'yes'
                ),
                'merchanttoken' => array(
                    'title' => __('توکن فروشنده', 'woocommerce'),
                    'type' => 'text',
                    'description' => __('توکن فروشنده برای اتصال به زرین پلاس', 'woocommerce')
                ),
                'success_message' => array(
                    'title' => __('پیام موفقیت پرداخت', 'woocommerce'),
                    'type' => 'textarea',
                    'default' => __('پرداخت شما با موفقیت انجام شد.', 'woocommerce')
                ),
                'failed_message' => array(
                    'title' => __('پیام شکست پرداخت', 'woocommerce'),
                    'type' => 'textarea',
                    'default' => __('پرداخت شما با مشکل مواجه شد.', 'woocommerce')
                ),
                'title' => array(
                    'title' => __('عنوان درگاه', 'woocommerce'),
                    'type' => 'text',
                    'default' => __('پرداخت زرین پلاس', 'woocommerce')
                ),
                'description' => array(
                    'title' => __('توضیحات درگاه', 'woocommerce'),
                    'type' => 'textarea',
                    'default' => __('پرداخت اعتباری زرین پلاس', 'woocommerce')
                ),
            );

            // اضافه کردن فیلدهای هر درگاه زیرمجموعه
            $extra_gateways = zarinplus_get_gateways();
            if (is_array($extra_gateways)) {
                foreach ($extra_gateways as $gw) {
                    if (!isset($gw['slug']) || $gw['slug'] === 'zarinplus') {
                        continue;
                    }
                    $slug = sanitize_title($gw['slug']);
                    $gw_title = isset($gw['title']) ? $gw['title'] : $slug;
                    $gw_desc = isset($gw['description']) ? $gw['description'] : '';

                    $fields[$slug . '_title'] = array(
                        'title' => __('عنوان درگاه', 'woocommerce'),
                        'type' => 'text',
                        'default' => $gw_title,
                    );
                    $fields[$slug . '_description'] = array(
                        'title' => __('توضیحات درگاه', 'woocommerce'),
                        'type' => 'textarea',
                        'default' => $gw_desc,
                    );
                }
            }

            $this->form_fields = $fields;
        }

        public function process_payment($order_id) {
            $order = wc_get_order($order_id);
            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_payment_url(true)
            );
        }

        /**
         * نمایش سفارشی فیلدها با تب‌بندی برای هر درگاه
         */
        public function admin_options() {
            // ۱) جمع‌آوری اطلاعات تب‌ها
            $tabs = array(
                array(
                    'slug'  => 'zarinplus',
                    'title' => __('زرین پلاس', 'woocommerce'),
                    'icon'  => plugin_dir_url(__FILE__) . 'assets/images/logo.png',
                    'desc'  => __('تنظیمات نمایش درگاه زرین پلاس در صفحه پرداخت', 'woocommerce'),
                    'fields' => array('title', 'description'),
                ),
            );
            $extra = zarinplus_get_gateways();
            if (is_array($extra)) {
                foreach ($extra as $gw) {
                    if (!isset($gw['slug']) || $gw['slug'] === 'zarinplus') continue;
                    $slug = sanitize_title($gw['slug']);
                    $tabs[] = array(
                        'slug'  => $slug,
                        'title' => isset($gw['title']) ? $gw['title'] : $slug,
                        'icon'  => isset($gw['icon']) ? $gw['icon'] : '',
                        'desc'  => sprintf(__('تنظیمات نمایش درگاه %s در صفحه پرداخت', 'woocommerce'), isset($gw['title']) ? $gw['title'] : $slug),
                        'fields' => array($slug . '_title', $slug . '_description'),
                    );
                }
            }

            // ۲) فیلدهای عمومی (شامل tabها نیست)
            $tab_keys = array();
            foreach ($tabs as $t) { $tab_keys = array_merge($tab_keys, $t['fields']); }
            $general_html = '';
            foreach ($this->form_fields as $key => $field) {
                if (in_array($key, $tab_keys, true)) continue;
                $field['id'] = $this->plugin_id . $this->id . '_' . $key;
                $field['name'] = 'woocommerce_' . $this->id . '_' . $key;
                ob_start();
                $type = isset($field['type']) ? $field['type'] : 'text';
                $method = 'generate_' . $type . '_html';
                if (method_exists($this, $method)) {
                    echo $this->{$method}($key, $field);
                } else {
                    echo $this->generate_text_html($key, $field);
                }
                $general_html .= ob_get_clean();
            }

            // ۳) HTML هر تب
            $tabs_html = '';
            foreach ($tabs as $t) {
                $body = '';
                foreach ($t['fields'] as $key) {
                    if (!isset($this->form_fields[$key])) continue;
                    $field = $this->form_fields[$key];
                    $type = isset($field['type']) ? $field['type'] : 'text';
                    $method = 'generate_' . $type . '_html';
                    if (method_exists($this, $method)) {
                        $body .= $this->{$method}($key, $field);
                    } else {
                        $body .= $this->generate_text_html($key, $field);
                    }
                }
                $tabs_html .= '<div class="zp-pane" data-pane="' . esc_attr($t['slug']) . '"><table class="form-table"><tbody>' . $body . '</tbody></table></div>';
            }
            ?>
            <style>
                .zp-wrapper { background:#fff; border:1px solid #e5e5e5; border-radius:8px; padding:24px; margin-top:16px; box-shadow:0 1px 2px rgba(0,0,0,.04); }
                .zp-section-title { font-size:16px; font-weight:600; margin:0 0 16px; color:#1d2327; }
                .zp-general { padding-bottom:16px; margin-bottom:24px; border-bottom:1px solid #eee; }
                .zp-tabs-wrapper { margin-top:8px; }
                .zp-tabs { display:flex; gap:4px; border-bottom:1px solid #dcdcde; margin-bottom:0; flex-wrap:wrap; padding:0; }
                .zp-tab { padding:10px 18px; cursor:pointer; background:transparent; border:none; border-bottom:3px solid transparent; margin-bottom:-1px; display:flex; align-items:center; gap:8px; font-size:14px; color:#50575e; transition:all .15s; }
                .zp-tab:hover { color:#2271b1; }
                .zp-tab img { height:22px; width:auto; object-fit:contain; }
                .zp-tab.active { color:#2271b1; border-bottom-color:#2271b1; font-weight:600; }
                .zp-panes { padding-top:20px; }
                .zp-pane { display:none; }
                .zp-pane.active { display:block; }
                .zp-pane .form-table { margin-top:0; }
                .zp-pane-desc { color:#646970; margin:0 0 16px; font-size:13px; }
            </style>
            <div class="zp-wrapper">
                <h2 style="margin-top:0;"><?php echo esc_html($this->get_method_title()); ?></h2>
                <p class="zp-pane-desc"><?php echo wp_kses_post($this->get_method_description()); ?></p>

                <div class="zp-general">
                    <h3 class="zp-section-title"><?php esc_html_e('تنظیمات عمومی', 'woocommerce'); ?></h3>
                    <table class="form-table"><tbody><?php echo $general_html; ?></tbody></table>
                </div>

                <div class="zp-tabs-wrapper">
                    <h3 class="zp-section-title"><?php esc_html_e('تنظیمات درگاه‌ها', 'woocommerce'); ?></h3>
                    <div class="zp-tabs" role="tablist">
                        <?php foreach ($tabs as $idx => $t): ?>
                            <button type="button" class="zp-tab<?php echo $idx === 0 ? ' active' : ''; ?>" data-target="<?php echo esc_attr($t['slug']); ?>">
                                <?php if (!empty($t['icon'])): ?>
                                    <img src="<?php echo esc_url($t['icon']); ?>" alt="">
                                <?php endif; ?>
                                <span><?php echo esc_html($t['title']); ?></span>
                            </button>
                        <?php endforeach; ?>
                    </div>
                    <div class="zp-panes">
                        <?php foreach ($tabs as $idx => $t): ?>
                            <div class="zp-pane<?php echo $idx === 0 ? ' active' : ''; ?>" data-pane="<?php echo esc_attr($t['slug']); ?>">
                                <p class="zp-pane-desc"><?php echo esc_html($t['desc']); ?></p>
                                <table class="form-table"><tbody>
                                    <?php
                                    foreach ($t['fields'] as $key) {
                                        if (!isset($this->form_fields[$key])) continue;
                                        $field = $this->form_fields[$key];
                                        $type = isset($field['type']) ? $field['type'] : 'text';
                                        $method = 'generate_' . $type . '_html';
                                        if (method_exists($this, $method)) {
                                            echo $this->{$method}($key, $field);
                                        } else {
                                            echo $this->generate_text_html($key, $field);
                                        }
                                    }
                                    ?>
                                </tbody></table>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <script>
            (function(){
                var tabs = document.querySelectorAll('.zp-tab');
                tabs.forEach(function(tab){
                    tab.addEventListener('click', function(e){
                        e.preventDefault();
                        var target = tab.dataset.target;
                        document.querySelectorAll('.zp-tab').forEach(function(t){ t.classList.remove('active'); });
                        document.querySelectorAll('.zp-pane').forEach(function(p){ p.classList.remove('active'); });
                        tab.classList.add('active');
                        var pane = document.querySelector('.zp-pane[data-pane="' + target + '"]');
                        if (pane) pane.classList.add('active');
                    });
                });
            })();
            </script>
            <?php
        }

        protected function get_merchant_token() {
            $main_settings = get_option('woocommerce_WC_ZarinPlus_settings', array());
            return isset($main_settings['merchanttoken']) ? $main_settings['merchanttoken'] : '';
        }

        protected function convert_amount($amount, $currency) {
            switch ($currency) {
                case 'IRT':
                    $amount *= 10;
                    break;
                case 'IRHT':
                    $amount *= 100;
                    break;
            }
            return $amount;
        }

        public function send_to_zarinplus_gateway($order_id) {
            $order = wc_get_order($order_id);
            $amount = $this->convert_amount(intval($order->get_total()), $order->get_currency());

            // تعیین gateway_slug از روی payment_method سفارش (case-insensitive)
            $payment_method = $order->get_payment_method();
            $payment_method_lower = strtolower($payment_method);
            $gateway_slug = 'zarinplus';
            if (strpos($payment_method_lower, 'wc_zarinplus_') === 0) {
                $gateway_slug = substr($payment_method_lower, strlen('wc_zarinplus_'));
            }

            $successUrl = add_query_arg('wc_order', $order_id, WC()->api_request_url($payment_method_lower));
            $cancelUrl = wc_get_checkout_url();

            $data = array(
                'amount' => $amount,
                'success' => $successUrl,
                'cancel' => $cancelUrl,
                'item' => 'Order #' . $order->get_order_number(),
                'cellphone' => $order->get_billing_phone(),
                'email' => $order->get_billing_email(),
                'token' => $this->get_merchant_token(),
                'gateway_slug' => $gateway_slug,
            );

            $response = $this->send_request_to_zarinplus('request', $data);

            if ($response && isset($response['status']) && $response['status'] === true) {
                wp_redirect($response['redirect_url']);
                exit;
            } else {
                wc_add_notice(__('خطا در ارتباط با زرین پلاس', 'woocommerce'), 'error');
                wp_redirect(wc_get_checkout_url());
                exit;
            }
        }

        public function return_from_zarinplus_gateway() {
            if (isset($_GET['wc_order']) && isset($_GET['authority'])) {
                $order_id = sanitize_text_field($_GET['wc_order']);
                $order = wc_get_order($order_id);
                $amount = $this->convert_amount(intval($order->get_total()), $order->get_currency());

                $data = array(
                    'authority' => sanitize_text_field($_GET['authority']),
                    'token' => $this->get_merchant_token(),
                    'amount' => $amount
                );

                $response = $this->send_request_to_zarinplus('verify', $data);

                if ($response && isset($response['status']) && $response['status'] === true && isset($response['data']['code'])) {
                    $code = $response['data']['code'];
                    if ($code == 200) {
                        $reference = isset($response['data']['reference']) ? sanitize_text_field($response['data']['reference']) : '';
                        $order->add_order_note(sprintf(__('پرداخت با موفقیت انجام شد. شناسه پرداخت: %s', 'woocommerce'), $reference));
                        $order->payment_complete($reference);
                        wc_add_notice($this->successMessage, 'success');
                        wp_redirect($this->get_return_url($order));
                        exit;
                    } elseif ($code == 201) {
                        wc_add_notice($this->successMessage, 'success');
                        wp_redirect($this->get_return_url($order));
                        exit;
                    } else {
                        wc_add_notice($this->failedMessage, 'error');
                        wp_redirect(wc_get_checkout_url());
                        exit;
                    }
                } else {
                    wc_add_notice(__('پرداخت ناموفق بوده است', 'woocommerce'), 'error');
                    wp_redirect(wc_get_checkout_url());
                    exit;
                }
            } else {
                wc_add_notice(__('اطلاعات لازم برای پردازش پرداخت موجود نیست.', 'woocommerce'), 'error');
                wp_redirect(wc_get_checkout_url());
                exit;
            }
        }

        public function cancel_transaction($authority) {
            $data = array('authority' => $authority);
            $response = $this->send_request_to_zarinplus('cancel', $data);
            if ($response && isset($response['status']) && $response['status'] === true) {
                wc_add_notice(__('تراکنش با موفقیت لغو شد.', 'woocommerce'), 'success');
                return true;
            } else {
                wc_add_notice(__('خطا در لغو تراکنش', 'woocommerce'), 'error');
                return false;
            }
        }

        public function reverse_transaction($authority, $reference) {
            $data = array(
                'authority' => $authority,
                'reference' => $reference,
                'token' => $this->get_merchant_token()
            );
            $response = $this->send_request_to_zarinplus('reverse', $data);
            if ($response && isset($response['status']) && $response['status'] === true && isset($response['data']['code']) && $response['data']['code'] == 101) {
                wc_add_notice(__('تراکنش با موفقیت بازگشت داده شد.', 'woocommerce'), 'success');
                return true;
            } else {
                wc_add_notice(__('خطا در بازگشت تراکنش', 'woocommerce'), 'error');
                return false;
            }
        }

        protected function send_request_to_zarinplus($action, $params) {
            $urls = array(
                'request' => 'https://api.zarinplus.com/payment/v2/request',
                'verify'  => 'https://api.zarinplus.com/payment/v2/verify',
                'cancel'  => 'https://api.zarinplus.com/payment/v2/cancel',
                'reverse' => 'https://api.zarinplus.com/payment/v2/reverse',
            );

            if (!isset($urls[$action])) {
                return false;
            }

            $response = wp_remote_post($urls[$action], array(
                'body' => json_encode($params),
                'headers' => array('Content-Type' => 'application/json'),
                'method' => 'POST',
                'timeout' => 30,
            ));

            if (is_wp_error($response)) {
                return false;
            }

            return json_decode(wp_remote_retrieve_body($response), true);
        }
    }

    /**
     * کلاس پایه برای تمام درگاه‌های داینامیک زرین‌پلاس
     * هر درگاه جدید از API به صورت خودکار با این کلاس ثبت می‌شه
     */
    class WC_ZarinPlus_Dynamic extends WC_ZarinPlus {
        protected $_dynamic_slug = '';

        public function init_for_slug($slug) {
            $this->_dynamic_slug = $slug;
            $this->id = 'WC_ZarinPlus_' . $slug;
            $this->gateway_slug = $slug;

            $info = zarinplus_get_gateway_info($slug);
            $default_title = ($info && isset($info['title'])) ? $info['title'] : $slug;
            $default_desc  = ($info && isset($info['description'])) ? $info['description'] : '';
            $icon_url      = ($info && !empty($info['icon'])) ? $info['icon'] : '';

            $this->method_title       = $default_title;
            $this->method_description = $default_desc;
            $this->icon               = apply_filters('WC_ZarinPlus_logo_' . $slug, $icon_url);
            $this->has_fields         = false;

            $main_settings = get_option('woocommerce_WC_ZarinPlus_settings', array());

            $this->enabled      = isset($main_settings['enabled']) ? $main_settings['enabled'] : 'yes';
            $title_key          = $slug . '_title';
            $desc_key           = $slug . '_description';
            $this->title        = (!empty($main_settings[$title_key])) ? $main_settings[$title_key] : $default_title;
            $this->description  = (!empty($main_settings[$desc_key]))  ? $main_settings[$desc_key]  : $default_desc;
            $this->merchantToken  = isset($main_settings['merchanttoken'])   ? $main_settings['merchanttoken']   : '';
            $this->successMessage = isset($main_settings['success_message']) ? $main_settings['success_message'] : __('پرداخت شما با موفقیت انجام شد.', 'woocommerce');
            $this->failedMessage  = isset($main_settings['failed_message'])  ? $main_settings['failed_message']  : __('پرداخت شما با مشکل مواجه شد.', 'woocommerce');

            $this->form_fields = array();
            $this->settings    = array();

            add_action('woocommerce_receipt_' . $this->id, array($this, 'send_to_zarinplus_gateway'));
            add_action('woocommerce_api_' . strtolower($this->id), array($this, 'return_from_zarinplus_gateway'));
        }

        public function init_form_fields() {
            $this->form_fields = array();
        }

        public function admin_options() {
            wp_safe_redirect(admin_url('admin.php?page=wc-settings&tab=checkout&section=wc_zarinplus'));
            exit;
        }

        public function is_available() {
            $main_settings = get_option('woocommerce_WC_ZarinPlus_settings', array());
            if (!isset($main_settings['enabled']) || $main_settings['enabled'] !== 'yes') {
                return false;
            }
            if (empty($main_settings['merchanttoken'])) {
                return false;
            }
            if (!zarinplus_get_gateway_info($this->_dynamic_slug)) {
                return false;
            }
            return true;
        }
    }

    // ثبت درگاه‌ها در ووکامرس - داینامیک بر اساس API
    add_filter('woocommerce_payment_gateways', function ($methods) {
        $methods[] = 'WC_ZarinPlus';

        $gateways = zarinplus_get_gateways();
        if (is_array($gateways)) {
            foreach ($gateways as $gw) {
                if (!isset($gw['slug']) || $gw['slug'] === 'zarinplus') {
                    continue;
                }
                $slug       = sanitize_title($gw['slug']);
                $class_name = 'WC_ZarinPlus_' . $slug;

                if (!class_exists($class_name)) {
                    // ساخت داینامیک کلاس برای درگاه جدید
                    $code = 'class ' . $class_name . ' extends WC_ZarinPlus_Dynamic {
                        public function __construct() { $this->init_for_slug("' . addslashes($slug) . '"); }
                    }';
                    eval($code); // phpcs:ignore Squiz.PHP.Eval.Discouraged
                }

                $methods[] = $class_name;
            }
        }

        return $methods;
    });

    // گروه‌بندی درگاه‌های زرین‌پلاس در صفحه چک‌اوت
    // درگاه‌های زرین‌پلاس کنار هم می‌مونن، ولی موقعیت گروه را ترتیب ادمین تعیین می‌کنه
    add_filter('woocommerce_available_payment_gateways', function ($available_gateways) {
        if (!is_array($available_gateways) || empty($available_gateways)) {
            return $available_gateways;
        }

        $zp_main_key = null;
        $zp_main = array();
        $zp_subs = array();
        $first_zp_position = null;
        $position = 0;

        foreach ($available_gateways as $id => $gw) {
            $is_main = ($id === 'WC_ZarinPlus');
            $is_sub  = (strpos($id, 'WC_ZarinPlus_') === 0);

            if ($is_main || $is_sub) {
                if ($first_zp_position === null) {
                    $first_zp_position = $position;
                }
                if ($is_main) {
                    $zp_main[$id] = $gw;
                } else {
                    $zp_subs[$id] = $gw;
                }
            }
            $position++;
        }

        // اگر هیچ درگاه زرین‌پلاس نداریم، تغییری نده
        if ($first_zp_position === null) {
            return $available_gateways;
        }

        // درگاه‌های زرین‌پلاس را از لیست اصلی حذف کن
        $others = array();
        foreach ($available_gateways as $id => $gw) {
            if ($id === 'WC_ZarinPlus' || strpos($id, 'WC_ZarinPlus_') === 0) {
                continue;
            }
            $others[$id] = $gw;
        }

        $zp_group = array_merge($zp_main, $zp_subs);

        // درج گروه در موقعیت اولین درگاه زرین‌پلاس از ترتیب اصلی
        $before = array_slice($others, 0, $first_zp_position, true);
        $after  = array_slice($others, $first_zp_position, null, true);

        return array_merge($before, $zp_group, $after);
    }, 99);

    // مخفی کردن درگاه‌های زیرمجموعه از response REST API ووکامرس
    // و افزودن لوگوی درگاه‌های زیرمجموعه به آیتم زرین‌پلاس (مثل تگ‌های Woo)
    add_filter('rest_post_dispatch', function ($response, $server, $request) {
        if (!$response instanceof WP_REST_Response) {
            return $response;
        }

        $route = $request->get_route();
        $is_payment_route = strpos($route, '/payments') !== false
            || strpos($route, '/payment_gateways') !== false;

        if (!$is_payment_route) {
            return $response;
        }

        // ساخت لیست آیکن درگاه‌های زیرمجموعه برای نمایش زیر کارت زرین‌پلاس
        $sub_gateway_logos = array();
        $sub_gateways_data = function_exists('zarinplus_get_gateways') ? zarinplus_get_gateways() : array();
        if (is_array($sub_gateways_data)) {
            foreach ($sub_gateways_data as $gw) {
                if (!isset($gw['slug']) || $gw['slug'] === 'zarinplus') {
                    continue;
                }
                if (!empty($gw['icon'])) {
                    $sub_gateway_logos[] = array(
                        'id'    => sanitize_title($gw['slug']),
                        'title' => isset($gw['title']) ? $gw['title'] : $gw['slug'],
                        'image' => $gw['icon'],
                        'icon'  => $gw['icon'],
                    );
                }
            }
        }

        $data = $response->get_data();

        $filter_item = function ($item) use (&$filter_item, $sub_gateway_logos) {
            if (!is_array($item)) {
                return $item;
            }

            // حذف درگاه‌های زیرمجموعه زرین‌پلاس
            if (isset($item['id']) && is_string($item['id'])) {
                $lower_id = strtolower($item['id']);
                if (strpos($lower_id, 'wc_zarinplus_') === 0 && $lower_id !== 'wc_zarinplus') {
                    return null;
                }
                // (آیکن‌ها از طریق inject DOM در صفحه admin اضافه میشن - پایین این فایل)
            }

            // پردازش بازگشتی کلیدهای احتمالی که حاوی لیست gateway هستن
            foreach (array('offline_payment_methods', 'other_payment_gateways', 'suggestions', 'providers', 'gateways') as $list_key) {
                if (isset($item[$list_key]) && is_array($item[$list_key])) {
                    $item[$list_key] = array_values(array_filter(array_map($filter_item, $item[$list_key])));
                }
            }
            return $item;
        };

        if (is_array($data)) {
            if (isset($data[0])) {
                $data = array_values(array_filter(array_map($filter_item, $data)));
            } else {
                $data = $filter_item($data);
            }
            $response->set_data($data);
        }

        return $response;
    }, 20, 3);

    // اینجکت لوگوی درگاه‌های زیرمجموعه زیر کارت زرین‌پلاس در صفحه Payment Providers
    add_action('admin_footer', function () {
        if (!is_admin()) {
            return;
        }
        // فقط در صفحه‌های wc-admin payments
        $on_payments_page = (isset($_GET['page']) && $_GET['page'] === 'wc-admin'
            && isset($_GET['path']) && strpos($_GET['path'], '/payments') !== false)
            || (isset($_GET['page']) && $_GET['page'] === 'wc-settings'
                && isset($_GET['tab']) && $_GET['tab'] === 'checkout'
                && !isset($_GET['section']));

        if (!$on_payments_page) {
            return;
        }

        $logos = array();

        // آیکن خود زرین‌پلاس همیشه اول لیست
        $zp_info = function_exists('zarinplus_get_gateway_info') ? zarinplus_get_gateway_info('zarinplus') : null;
        $zp_icon = ($zp_info && !empty($zp_info['icon'])) ? $zp_info['icon'] : plugin_dir_url(__FILE__) . 'assets/images/logo.png';
        $logos[] = array(
            'title' => 'زرین پلاس',
            'icon'  => $zp_icon,
        );

        if (function_exists('zarinplus_get_gateways')) {
            $gws = zarinplus_get_gateways();
            if (is_array($gws)) {
                foreach ($gws as $gw) {
                    if (!isset($gw['slug']) || $gw['slug'] === 'zarinplus') {
                        continue;
                    }
                    if (!empty($gw['icon'])) {
                        $logos[] = array(
                            'title' => isset($gw['title']) ? $gw['title'] : $gw['slug'],
                            'icon'  => $gw['icon'],
                        );
                    }
                }
            }
        }

        if (empty($logos)) {
            return;
        }
        ?>
        <style>
            .zp-sub-logos { display:flex; flex-wrap:wrap; gap:5px; margin-top:7px; align-items:center; }
            .zp-sub-logos img { height:22px; width:auto; border-radius:3px; border:1px solid #e0e0e0; padding:2px 6px; background:#fff; box-sizing:content-box; }
        </style>
        <script>
        (function(){
            var logos = <?php echo wp_json_encode($logos); ?>;
            if (!logos || !logos.length) return;

            function buildLogosHTML() {
                var html = '<div class="zp-sub-logos">';
                logos.forEach(function(l){
                    html += '<img src="'+l.icon+'" alt="'+l.title+'" title="'+l.title+'" />';
                });
                html += '</div>';
                return html;
            }

            function inject() {
                // پیدا کردن متن "پرداخت اعتباری زرین پلاس" یا متن description ذخیره‌شده
                // و درج آیکن‌ها بلافاصله بعد از همان element
                var descCandidates = ['پرداخت اعتباری زرین پلاس', 'پرداخت زرین پلاس'];

                // احتمالاً description خود کاربر هم متفاوت ست شده - از option می‌خونیم
                var customDesc = '<?php
                    $s = get_option('woocommerce_WC_ZarinPlus_settings', array());
                    echo esc_js(isset($s['description']) ? $s['description'] : '');
                ?>';
                if (customDesc) descCandidates.unshift(customDesc);

                // پیدا کردن element با text matching
                var allEls = document.querySelectorAll('p, span, div, small');
                for (var i=0; i<allEls.length; i++) {
                    var el = allEls[i];
                    if (el.children && el.children.length > 0) continue; // فقط leaf node ها
                    var text = (el.textContent || '').trim();
                    if (!text) continue;

                    var matched = false;
                    for (var j=0; j<descCandidates.length; j++) {
                        if (descCandidates[j] && text === descCandidates[j]) {
                            matched = true;
                            break;
                        }
                    }
                    if (!matched) continue;

                    // بررسی اینکه قبلاً اضافه نشده
                    var parent = el.parentElement;
                    if (parent && parent.querySelector('.zp-sub-logos')) continue;
                    if (el.nextElementSibling && el.nextElementSibling.classList && el.nextElementSibling.classList.contains('zp-sub-logos')) continue;

                    el.insertAdjacentHTML('afterend', buildLogosHTML());
                    return; // فقط یکبار
                }

                // fallback: نسخه قدیم tr-based
                document.querySelectorAll('tr[data-gateway_id="wc_zarinplus"]').forEach(function(tr){
                    var descCell = tr.querySelector('td.name .gateway-description, td.name p, td.name');
                    if (descCell && !descCell.querySelector('.zp-sub-logos')) {
                        descCell.insertAdjacentHTML('beforeend', buildLogosHTML());
                    }
                });
            }

            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', inject);
            } else {
                inject();
            }
            // برای React که async رندر می‌کنه
            var observer = new MutationObserver(function(){ inject(); });
            observer.observe(document.body, { childList: true, subtree: true });
        })();
        </script>
        <?php
    });
}

add_action('plugins_loaded', 'Load_ZarinPlus_Gateway', 0);
