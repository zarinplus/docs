<?php
use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class WC_Zarinplus_Gateway_Blocks_Support extends AbstractPaymentMethodType {
    private $gateway;
    protected $name = 'WC_ZarinPlus';
    private $gateway_slug = null;

    public function __construct($gateway_slug = null) {
        if ($gateway_slug && $gateway_slug !== 'zarinplus') {
            $this->gateway_slug = $gateway_slug;
            $this->name = 'WC_ZarinPlus_' . sanitize_title($gateway_slug);
        }
    }

    public function initialize() {
        // تنظیمات همه‌ی درگاه‌ها (zarinplus + زیرمجموعه‌ها) در option زرین‌پلاس اصلی ذخیره میشه
        $this->settings = get_option('woocommerce_WC_ZarinPlus_settings', array());
        $gateways = WC()->payment_gateways->payment_gateways();
        if (isset($gateways[$this->name])) {
            $this->gateway = $gateways[$this->name];
        }
    }

    public function is_active() {
        if (empty($this->settings)) {
            return true;
        }
        // وضعیت فعال همه درگاه‌ها وابسته به درگاه اصلی زرین‌پلاس
        return !isset($this->settings['enabled']) || 'yes' === $this->settings['enabled'];
    }

    public function get_payment_method_script_handles() {
        $handle = 'wc-zarinplus-blocks-integration';

        if (!wp_script_is($handle, 'registered')) {
            wp_register_script(
                $handle,
                plugin_dir_url(__DIR__) . 'assets/js/index.js',
                array(
                    'wc-blocks-registry',
                    'wc-settings',
                    'wp-element',
                    'wp-html-entities',
                    'wp-i18n',
                ),
                null,
                true
            );

            $gateway_ids = array('WC_ZarinPlus');
            if (function_exists('zarinplus_get_gateways')) {
                $gateways = zarinplus_get_gateways();
                if (is_array($gateways)) {
                    foreach ($gateways as $gw) {
                        if (isset($gw['slug']) && $gw['slug'] !== 'zarinplus') {
                            $gateway_ids[] = 'WC_ZarinPlus_' . sanitize_title($gw['slug']);
                        }
                    }
                }
            }

            wp_localize_script($handle, 'zarinplus_block_gateways', $gateway_ids);
        }

        return array($handle);
    }

    public function get_payment_method_data() {
        $icon = plugin_dir_url(__DIR__) . 'assets/images/logo.png';
        $title = '';
        $description = '';

        if ($this->gateway_slug) {
            // درگاه زیرمجموعه (مثل وایب) - تنظیمات با prefix slug از option زرین‌پلاس اصلی خونده میشه
            $slug_key = sanitize_title($this->gateway_slug);
            $title = isset($this->settings[$slug_key . '_title']) ? $this->settings[$slug_key . '_title'] : '';
            $description = isset($this->settings[$slug_key . '_description']) ? $this->settings[$slug_key . '_description'] : '';

            // fallback: از اطلاعات API
            if (empty($title) && function_exists('zarinplus_get_gateway_info')) {
                $info = zarinplus_get_gateway_info($this->gateway_slug);
                if ($info) {
                    if (empty($title)) {
                        $title = isset($info['title']) ? $info['title'] : '';
                    }
                    if (empty($description)) {
                        $description = isset($info['description']) ? $info['description'] : '';
                    }
                    if (!empty($info['icon'])) {
                        $icon = $info['icon'];
                    }
                }
            }

            // اگه gateway instance داریم، آیکن رو از اون بگیر
            if ($this->gateway && !empty($this->gateway->icon)) {
                $icon = $this->gateway->icon;
            }
        } else {
            // درگاه اصلی زرین‌پلاس - تنظیمات با کلیدهای مستقیم
            $title = isset($this->settings['title']) ? $this->settings['title'] : '';
            $description = isset($this->settings['description']) ? $this->settings['description'] : '';

            if ($this->gateway && !empty($this->gateway->icon)) {
                $icon = $this->gateway->icon;
            }
        }

        return array(
            'title'       => $title,
            'description' => $description,
            'icon'        => $icon,
            'name'        => $this->name,
        );
    }
}
