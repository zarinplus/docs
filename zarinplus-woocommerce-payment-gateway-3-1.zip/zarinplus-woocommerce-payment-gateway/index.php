<?php
/*
Plugin Name: افزونه پرداخت زرین پلاس برای ووکامرس
Version: 3.1
Description: افزونه درگاه پرداخت امن زرین پلاس برای فروشگاه ساز ووکامرس - پشتیبانی از چند درگاه
Plugin URI: http://zarinplus.com
Author: Armin Zahedi
Author URI: http://www.zarinplus.com/

*/

include_once("class-wc-gateway-zarinplus.php");

add_action('before_woocommerce_init', function () {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
});

add_action('woocommerce_blocks_loaded', 'zarinplus_gateway_block_support');
function zarinplus_gateway_block_support()
{
    require_once __DIR__ . '/includes/class-wc-zarinplus-gateway-blocks-support.php';

    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function (Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry) {
            // درگاه اصلی
            $payment_method_registry->register(new WC_Zarinplus_Gateway_Blocks_Support());

            // درگاه‌های اضافی
            if (function_exists('zarinplus_get_gateways')) {
                $gateways = zarinplus_get_gateways();
                if (is_array($gateways)) {
                    foreach ($gateways as $gw) {
                        if (!isset($gw['slug']) || $gw['slug'] === 'zarinplus') {
                            continue;
                        }
                        $payment_method_registry->register(new WC_Zarinplus_Gateway_Blocks_Support($gw['slug']));
                    }
                }
            }
        }
    );
}
