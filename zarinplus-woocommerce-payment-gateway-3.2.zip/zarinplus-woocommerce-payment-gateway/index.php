<?php
/*
Plugin Name: افزونه پرداخت زرین پلاس برای ووکامرس
Version: 3.2
Description: افزونه درگاه پرداخت امن زرین پلاس برای فروشگاه ساز ووکامرس - پشتیبانی از چند درگاه
Plugin URI: http://zarinplus.com
Author: Armin Zahedi
Author URI: http://www.zarinplus.com/

*/

include_once("class-wc-gateway-zarinplus.php");

add_action('before_woocommerce_init', function () {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
});

/**
 * REST API endpoint برای healthcheck پلاگین
 * GET /wp-json/zarinplus/v1/healthcheck
 *
 * خروجی: نسخه پلاگین، وضعیت اتصال به API زرین‌پلاس، latency، لیست درگاه‌ها
 * عمدا اطلاعات حساس (token) نشون داده نمی‌شه
 */
add_action('rest_api_init', function () {
    register_rest_route('zarinplus/v1', '/healthcheck', array(
        'methods'  => 'GET',
        'callback' => 'zarinplus_healthcheck_callback',
        'permission_callback' => '__return_true',
    ));
});

function zarinplus_healthcheck_callback() {
    $plugin_data = get_file_data(__FILE__, array('Version' => 'Version'), 'plugin');
    $version = isset($plugin_data['Version']) ? $plugin_data['Version'] : 'unknown';

    $main_settings = get_option('woocommerce_WC_ZarinPlus_settings', array());
    $token         = isset($main_settings['merchanttoken']) ? $main_settings['merchanttoken'] : '';
    $enabled       = isset($main_settings['enabled']) ? $main_settings['enabled'] : 'no';

    $result = array(
        'plugin'          => 'zarinplus-woocommerce-payment-gateway',
        'version'         => $version,
        'enabled'         => ($enabled === 'yes'),
        'has_token'       => !empty($token),
        'woocommerce'     => class_exists('WooCommerce'),
        'site_url'        => get_site_url(),
        'timestamp'       => gmdate('c'),
        'connection'      => array(
            'status'        => 'unknown',
            'http_code'     => null,
            'latency_ms'    => null,
            'error'         => null,
            'api_response'  => null,
        ),
        'gateways'        => array(
            'count'         => 0,
            'list'          => array(),
            'source'        => null,
        ),
    );

    if (empty($token)) {
        $result['connection']['status'] = 'skipped';
        $result['connection']['error']  = 'no merchant token configured';
        return new WP_REST_Response($result, 200);
    }

    // درخواست live به API برای trace اتصال
    $start = microtime(true);
    $response = wp_remote_post('https://api.zarinplus.com/payment/gateways/', array(
        'body'    => json_encode(array('token' => $token)),
        'headers' => array('Content-Type' => 'application/json'),
        'method'  => 'POST',
        'timeout' => 10,
    ));
    $latency_ms = round((microtime(true) - $start) * 1000);
    $result['connection']['latency_ms'] = $latency_ms;

    if (is_wp_error($response)) {
        $result['connection']['status'] = 'error';
        $result['connection']['error']  = $response->get_error_message();
    } else {
        $http_code = wp_remote_retrieve_response_code($response);
        $body      = json_decode(wp_remote_retrieve_body($response), true);
        $result['connection']['http_code'] = $http_code;

        if ($http_code >= 200 && $http_code < 300 && is_array($body) && !empty($body['status'])) {
            $result['connection']['status']       = 'ok';
            $result['connection']['api_response'] = isset($body['message']) ? $body['message'] : 'ok';
        } else {
            $result['connection']['status'] = 'error';
            $result['connection']['error']  = isset($body['message']) ? $body['message'] : 'invalid response';
        }
    }

    // لیست درگاه‌ها (از کش یا fallback) - بدون اطلاعات حساس
    if (function_exists('zarinplus_get_gateways')) {
        $gateways = zarinplus_get_gateways();
        $result['gateways']['source'] = ($result['connection']['status'] === 'ok') ? 'live_or_cache' : 'fallback';
        if (is_array($gateways)) {
            foreach ($gateways as $gw) {
                if (!isset($gw['slug'])) continue;
                $result['gateways']['list'][] = array(
                    'slug'  => $gw['slug'],
                    'title' => isset($gw['title']) ? $gw['title'] : $gw['slug'],
                );
            }
            $result['gateways']['count'] = count($result['gateways']['list']);
        }
    }

    return new WP_REST_Response($result, 200);
}

add_action('woocommerce_blocks_loaded', 'zarinplus_gateway_block_support');
function zarinplus_gateway_block_support()
{
    require_once __DIR__ . '/includes/class-wc-zarinplus-gateway-blocks-support.php';

    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function (Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry) {
            // درگاه اصلی
            $payment_method_registry->register(new WC_Zarinplus_Gateway_Blocks_Support());

            // درگاه‌های اضافی
            if (function_exists('zarinplus_get_gateways')) {
                $gateways = zarinplus_get_gateways();
                if (is_array($gateways)) {
                    foreach ($gateways as $gw) {
                        if (!isset($gw['slug']) || $gw['slug'] === 'zarinplus') {
                            continue;
                        }
                        $payment_method_registry->register(new WC_Zarinplus_Gateway_Blocks_Support($gw['slug']));
                    }
                }
            }
        }
    );
}
