<?php
/*
Plugin Name: افزونه پرداخت زرین پلاس برای ووکامرس
Version: 1.0
Description:  افزونه درگاه پرداخت امن زرین پلاش برای فروشگاه ساز ووکامرس
Plugin URI: http://zarunplus.com
Author: Armin Zahedi
Author URI: http://www.zarinplus.com/

*/
include_once("class-wc-gateway-zarinplus.php");
