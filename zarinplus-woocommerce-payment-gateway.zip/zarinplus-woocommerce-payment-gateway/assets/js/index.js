const zpp_settings = window.wc.wcSettings.getSetting( 'WC_ZarinPlus_data', {} );
const zpp_label = window.wp.htmlEntities.decodeEntities( zpp_settings.title ) || '';
const zpp_Content = () => {
    return window.wp.htmlEntities.decodeEntities( zpp_settings.description || '' );
};
const zpp_Icon = () => {
    return zpp_settings.icon
        ? React.createElement('img', { src: zpp_settings.icon, style: { marginLeft: '20px' } })
        : null;
}
const zpp_Label = () => {
    return React.createElement(
        'span',
        { style: { width: '100%', display: 'flex', gap: '5px' } },
        zpp_label,
        React.createElement(zpp_Icon)
    );
}
const zpp_Block_Gateway = {
    name: 'WC_ZarinPlus',
    label: React.createElement(zpp_Label),
    content: React.createElement(zpp_Content),
    edit: React.createElement(zpp_Content),
    canMakePayment: () => true,
    ariaLabel: zpp_label,
    supports: {
        features: zpp_settings.supports,
    },
};
window.wc.wcBlocksRegistry.registerPaymentMethod( zpp_Block_Gateway );