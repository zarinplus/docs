<?php

if (!defined('ABSPATH')) {
    exit;
}

function Load_ZarinPlus_Gateway()
{
    if (!function_exists('Woocommerce_Add_ZarinPlus_Gateway') && class_exists('WC_Payment_Gateway') && !class_exists('WC_ZarinPlus')) {

        add_filter('woocommerce_payment_gateways', 'Woocommerce_Add_ZarinPlus_Gateway');

        function Woocommerce_Add_ZarinPlus_Gateway($methods)
        {
            $methods[] = 'WC_ZarinPlus';
            return $methods;
        }

        add_filter('woocommerce_currencies', 'add_IR_currency_zarinplus');

        function add_IR_currency_zarinplus($currencies)
        {
            $currencies['IRR'] = __('ریال', 'woocommerce');
            $currencies['IRT'] = __('تومان', 'woocommerce');
            $currencies['IRHR'] = __('هزار ریال', 'woocommerce');
            $currencies['IRHT'] = __('هزار تومان', 'woocommerce');
            return $currencies;
        }

        add_filter('woocommerce_currency_symbol', 'add_IR_currency_symbol_zarinplus', 10, 2);

        function add_IR_currency_symbol_zarinplus($currency_symbol, $currency)
        {
            switch ($currency) {
                case 'IRR':
                    $currency_symbol = 'ریال';
                    break;
                case 'IRT':
                    $currency_symbol = 'تومان';
                    break;
                case 'IRHR':
                    $currency_symbol = 'هزار ریال';
                    break;
                case 'IRHT':
                    $currency_symbol = 'هزار تومان';
                    break;
            }
            return $currency_symbol;
        }

        class WC_ZarinPlus extends WC_Payment_Gateway
        {
            private $merchantToken;
            private $failedMessage;
            private $successMessage;

            public function __construct()
            {
                $this->id = 'WC_ZarinPlus';
                $this->method_title = __('زرین پلاس پرداخت', 'woocommerce');
                $this->method_description = __('تنظیمات پرداخت اعتباری زرین پلاس', 'woocommerce');
                $this->icon = apply_filters('WC_ZarinPlus_logo', plugin_dir_url(__FILE__) . 'assets/images/logo.png');
                $this->has_fields = false;

                $this->init_form_fields();
                $this->init_settings();

                $this->enabled = $this->get_option('enabled');
                $this->title = $this->settings['title'];
                $this->description = $this->settings['description'];
                $this->merchantToken = $this->settings['merchanttoken'];
                $this->successMessage = $this->settings['success_message'];
                $this->failedMessage = $this->settings['failed_message'];

                add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
                add_action('woocommerce_receipt_' . $this->id, array($this, 'send_to_zarinplus_gateway'));
                add_action('woocommerce_api_' . strtolower(get_class($this)), array($this, 'return_from_zarinplus_gateway'));
            }

            public function init_form_fields()
            {
                $this->form_fields = array(
                    'enabled' => array(
                        'title' => __('فعال‌سازی/غیرفعالسازی', 'woocommerce'),
                        'type' => 'checkbox',
                        'label' => __('فعال‌سازی درگاه زرین پلاس', 'woocommerce'),
                        'default' => 'yes',
                    ),
                    'title' => array(
                        'title' => __('عنوان درگاه', 'woocommerce'),
                        'type' => 'text',
                        'default' => __('پرداخت زرین پلاس', 'woocommerce'),
                    ),
                    'description' => array(
                        'title' => __('توضیحات درگاه', 'woocommerce'),
                        'type' => 'textarea',
                        'default' => __('پرداخت اعتباری زرین پلاس', 'woocommerce'),
                    ),
                    'merchanttoken' => array(
                        'title' => __('توکن فروشنده', 'woocommerce'),
                        'type' => 'text',
                        'description' => __('توکن فروشنده برای اتصال به زرین پلاس', 'woocommerce'),
                    ),
                    'success_message' => array(
                        'title' => __('پیام موفقیت پرداخت', 'woocommerce'),
                        'type' => 'textarea',
                        'default' => __('پرداخت شما با موفقیت انجام شد.', 'woocommerce'),
                    ),
                    'failed_message' => array(
                        'title' => __('پیام شکست پرداخت', 'woocommerce'),
                        'type' => 'textarea',
                        'default' => __('پرداخت شما با مشکل مواجه شد.', 'woocommerce'),
                    ),
                );
            }

            public function process_payment($order_id)
            {
                $order = wc_get_order($order_id);
                return array(
                    'result' => 'success',
                    'redirect' => $order->get_checkout_payment_url(true)
                );
            }

            public function send_to_zarinplus_gateway($order_id)
            {
                $order = wc_get_order($order_id);
                $amount = intval($order->get_total());
                $currency = $order->get_currency();
                 switch ($currency) {
                case 'IRT':
                    $amount *= 10;
                    break;
                case 'IRHR':
                    $amount *= 1;
                    break;
                case 'IRHT':
                    $amount *= 100;
                    break;
                case 'IRR':
                    $amount *= 1;
                    break;
            }
                $successUrl = add_query_arg('wc_order', $order_id, WC()->api_request_url('WC_ZarinPlus'));
                $cancelUrl = wc_get_checkout_url();

                $data = array(
                    'amount' => $amount,
                    'success' => $successUrl,
                    'cancel' => $cancelUrl,
                    'item' => 'Order #' . $order->get_order_number(),
                    'cellphone' => $order->get_billing_phone(),
                    'email' => $order->get_billing_email(),
                    'token' => $this->merchantToken,
                );

                $response = $this->send_request_to_zarinplus('request', $data);

                if ($response && $response['status'] == '200') {
                    wp_redirect($response['redirect_url']);
                    exit;
                } else {
                    wc_add_notice(__('خطا در ارتباط با زرین پلاس', 'woocommerce'), 'error');
                    wp_redirect(wc_get_checkout_url());
                    exit;
                }
            }

           public function return_from_zarinplus_gateway()
            {
                if (isset($_GET['wc_order']) && isset($_GET['authority'])) {
                    $order_id = sanitize_text_field($_GET['wc_order']);
                    $order = wc_get_order($order_id);
                    $amount = intval($order->get_total());
                    $currency = $order->get_currency();

                      switch ($currency) {
                case 'IRT':
                    $amount *= 10;
                    break;
                case 'IRHR':
                    $amount *= 1;
                    break;
                case 'IRHT':
                    $amount *= 100;
                    break;
                case 'IRR':
                    $amount *= 1;
                    break;
            }

                    $data = array(
                        'authority' => sanitize_text_field($_GET['authority']),
                        'token' => $this->merchantToken,
                        'amount' => $amount,
                    );

                    $response = $this->send_request_to_zarinplus('verify', $data);

                    if ($response && $response['status'] == '200') {
                        $order->payment_complete($response['reference']);
                        wc_add_notice($this->successMessage, 'success');
                        wp_redirect($this->get_return_url($order));
                        exit;
                    } else {
                        wc_add_notice($this->failedMessage, 'error');
                        wp_redirect(wc_get_checkout_url());
                        exit;
                    }
                } else {
                    wc_add_notice(__('اطلاعات لازم برای پردازش پرداخت موجود نیست.', 'woocommerce'), 'error');
                    wp_redirect(wc_get_checkout_url());
                    exit;
                }
            }


            public function cancel_transaction($authority)
            {
                $data = array(
                    'authority' => $authority,
                );

                $response = $this->send_request_to_zarinplus('cancel', $data);

                if ($response['status'] == 200) {
                    wc_add_notice(__('تراکنش با موفقیت لغو شد.', 'woocommerce'), 'success');
                    return true;
                } else {
                    wc_add_notice(__('خطا در لغو تراکنش', 'woocommerce'), 'error');
                    return false;
                }
            }

            public function reverse_transaction($authority, $reference)
            {
                $data = array(
                    'authority' => $authority,
                    'reference' => $reference,
                    'token' => $this->merchantToken,
                );

                $response = $this->send_request_to_zarinplus('reverse', $data);

                if ($response['status'] == '500') {
                    wc_add_notice(__('تراکنش با موفقیت بازگشت داده شد.', 'woocommerce'), 'success');
                    return true;
                } else {
                    wc_add_notice(__('خطا در بازگشت تراکنش', 'woocommerce'), 'error');
                    return false;
                }
            }

            private function send_request_to_zarinplus($action, $params)
            {
                $url = 'https://api.zarinplus.com/payment/' . $action;
                $response = wp_remote_post($url, array(
                'body' => json_encode($params),
                'headers' => array('Content-Type' => 'application/json'),
                'method' => 'POST',
            ));

            if (is_wp_error($response)) {
                return false; // یا می‌توانید اطلاعات خطا را چاپ کنید
            }

            $body = json_decode(wp_remote_retrieve_body($response), true);
            if (!isset($body['status'])) {
                // اینجا می‌توانید وضعیت پاسخ را چاپ کنید
                error_log(print_r($body, true));
                return false;
            }

            return $body;

                    }
    }
}
}

add_action('plugins_loaded', 'Load_ZarinPlus_Gateway', 0);
