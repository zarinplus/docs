<?php
/*
Plugin Name: افزونه پرداخت زرین پلاس برای ووکامرس
Version: 2.0
Description: افزونه درگاه پرداخت امن زرین پلاش برای فروشگاه ساز ووکامرس
Plugin URI: http://zarunplus.com
Author: Armin Zahedi
Author URI: http://www.zarinplus.com/

*/

include_once("class-wc-gateway-zarinplus.php");

add_action('before_woocommerce_init', function () {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
});

add_action('woocommerce_blocks_loaded', 'zarinplus_gateway_block_support');
function zarinplus_gateway_block_support()
{
    require_once __DIR__ . '/includes/class-wc-zarinplus-gateway-blocks-support.php';

    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function (Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry) {
            $payment_method_registry->register(new WC_Zarinplus_Gateway_Blocks_Support);
        }
    );
}
