<?php
/*
Plugin Name: افزونه پرداخت زرین پلاس برای ووکامرس
Version: 1.0
Description: پرداخت اعتباری زرین پلاس
Plugin URI: http://zarunplus.com
Author: Armin Zahedi
Author URI: http://www.zarinplus.com/

*/
include_once("class-wc-gateway-zarinplus.php");
